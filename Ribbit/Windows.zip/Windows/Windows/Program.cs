﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Windows
{
    class Program
    {
        static void Main(string[] args)
        {
            //This line initializes the list of windows
            //Feel free to change the values passed to the WindowGenerator function
            List<Window> windows = WindowGenerator(15,10000);

            //Your code here:


        }

        /// <summary>
        /// This method creates a list of windows by maximum size and number of windows
        /// </summary>
        /// <param name="maxWindowSize">The maximum X or Y size of the window</param>
        /// <param name="numberOfWindows">The number of windows to generate</param>
        /// <returns></returns>
        public static List<Window> WindowGenerator(int maxWindowSize, int numberOfWindows)
        {
            List<Window> Windows = new List<Window>();

            Random rand = new Random((int)DateTime.Now.Ticks);

            for (int i = 0; i < numberOfWindows; i++)
            {
                var x = rand.NextDouble() * (maxWindowSize - 1) + 1;
                var y = rand.NextDouble() * (maxWindowSize- 1) + 1;
                Windows.Add(new Window(x, y));
            }

            return Windows;
        }

    }
}
